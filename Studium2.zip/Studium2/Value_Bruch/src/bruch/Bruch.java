package bruch;

/**
 * Diese Klasse Bruch repr�sentiert einen Bruch mit Z�hler und Nenner.
 * 
 * @author Tobias Sigmann
 */
public class Bruch {
	/**
	 * zaehler speichert den Wert des Zaehlers Bruchs.
	 */
	private int zaehler;

	/**
	 * nenner speicher den Wert des Nenner eines Bruchs.
	 */
	private int nenner;

	/**
	 * Bruch erm�glicht die direkte Initialiesirung des Objettes mit festem
	 * Nenner und Zaehler.
	 * 
	 * @param zaehler
	 *            Ist der Zaehler des Bruchs.
	 * @param nenner
	 *            Ist der Nenner des Bruchs.
	 */
	public Bruch(int zaehler, int nenner) {
		if (nenner != 0) {
			this.nenner = nenner;
			this.zaehler = zaehler;
		}
	}

	/**
	 * addieren Addiert den �bergebenen Bruch auf diesen Bruch.
	 * 
	 * @param bruch
	 *            ist der zu addierender Bruch.
	 * @return Bruch mit dem Ergebnis der Addition.
	 */
	public Bruch addieren(Bruch bruch) {
		int newZaehler, newNenner;
		if (nenner == bruch.nenner) {
			newZaehler = this.getZaehler() + bruch.getZaehler();
			newNenner = this.getNenner();
		} else {
			int hilfsZaehler = bruch.zaehler * nenner;
			newZaehler = this.getZaehler() * bruch.getNenner();
			newZaehler += hilfsZaehler;
			newNenner = nenner * bruch.nenner;
		}
		return kuerzen(new Bruch(newZaehler, newNenner));
	}

	/**
	 * subtrahieren subtrahiert den �bergebenen Bruch auf diesen Bruch.
	 * 
	 * @param bruch
	 *            ist der zu subtrahierender Bruch.
	 * @return Bruch mit dem Ergebnis der Subtraktion.
	 */
	public Bruch subtrahieren(Bruch bruch) {
		int newZaehler, newNenner;
		if (nenner == bruch.nenner) {
			newZaehler = this.getZaehler() + bruch.zaehler;
			newNenner = bruch.getNenner();
		} else {
			int hilfsZaehler = bruch.zaehler * nenner;
			newZaehler= this.getZaehler() * bruch.nenner;
			newZaehler -= hilfsZaehler;
			newNenner = nenner * bruch.nenner;
		}
		return kuerzen(new Bruch(newZaehler, newNenner));
	}

	/**
	 * multiplizieren multipliziert den �bergebenen Bruch auf den aktuellen
	 * Bruch.
	 * 
	 * @param bruch
	 *            ist der zu multiplizierender Bruch.
	 * @return Bruch mit dem Ergebnis der Multiplikation.
	 */
	public Bruch multiplizieren(Bruch bruch) {
		int newZaehler, newNenner;
		newZaehler = zaehler * bruch.zaehler;
		newNenner = nenner * bruch.nenner;
		return kuerzen(new Bruch(newZaehler, newNenner));
	}

	/**
	 * dividieren dividiert den �bergebenen Bruch auf den aktuellen Bruch.
	 * 
	 * @param bruch
	 *            ist der zu dividierenden Bruch.
	 * @return Bruch mit dem Ergebnis der Divvision.
	 */
	public Bruch dividieren(Bruch bruch) {
		int newZaehler, newNenner;
		newZaehler = this.getZaehler() * bruch.nenner;
		newNenner = this.getNenner() * bruch.zaehler;
		return kuerzen(new Bruch(newZaehler, newNenner));
	}

	/**
	 * ggT berechnet den gr��ten geminsamen Teiler des zaehlers und eines
	 * �bergebenen Werted.
	 * 
	 * @param zaehler1
	 *            ist der Zaehler des ersten Bruchs.
	 * @param zaehler2
	 *            ist der Zaehler des zweiten Bruchs.
	 * @return Der gr��ten geminsamen Teiler.
	 */
	public int ggT(int zaehler1, int zaehler2) {
		zaehler1 = Math.abs(zaehler1);
		zaehler2 = Math.abs(zaehler2);
		if (zaehler1 != 0) {
			while (zaehler2 != 0) {
				if (zaehler1 > zaehler2) {
					zaehler1 = zaehler1 - zaehler2;
				} else {
					zaehler2 = zaehler2 - zaehler1;
				}
			}
			return zaehler1;
		} else {
			return 1;
		}
	}

	/**
	 * kuerzen k�rzt den Bruch.
	 * 
	 * @param bruch zu k�rzender Bruch.
	 * @return gek�rtzter Bruch.
	 */
	public Bruch kuerzen(Bruch bruch) {
		int teiler = ggT(bruch.getZaehler(), bruch.getNenner());
		int newNenner = bruch.getNenner() / teiler;
		int newZaehler = bruch.getZaehler() / teiler;
		return new Bruch(newZaehler, newNenner);
	}

	/**
	 * getNenner liefert den Nenner des Bruchs zur�ck.
	 * 
	 * @return Wert des Nenners.
	 */
	public int getNenner() {
		return nenner;
	}

	/**
	 * getZaehler liefert den Zaehler des Bruchs zur�ck.
	 * 
	 * @return Wert des Zaehlers.
	 */
	public int getZaehler() {
		return zaehler;
	}

}
