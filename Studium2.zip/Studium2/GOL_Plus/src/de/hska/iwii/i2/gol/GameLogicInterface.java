package de.hska.iwii.i2.gol;

public interface GameLogicInterface {
	public void setStartGeneration(boolean[][] generation);
	public void nextGeneration();
	public boolean isCellInNextGenerationAlive(int aroundAlive, int x, int y);
	public int countAliveAround(int x, int y);
	public boolean isCellAlive(int x, int y);
}
