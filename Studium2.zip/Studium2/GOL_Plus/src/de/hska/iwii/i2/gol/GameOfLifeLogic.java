package de.hska.iwii.i2.gol;

/**
 * Die eigentliche Spielelogik. Das Spielfeld wird hier nicht als zyklisch
 * geschlossen betrachtet wird.
 *
 * @author Holger Vogelsang
 */
public class GameOfLifeLogic implements GameLogicInterface{
	/**
	 * field speichert den aktuellen Spielstand.
	 */
	private boolean[][] field;

	/**
	 * setStartGeneration setzt das Spielfeld in den Startzustand.
	 * 
	 * @param generation
	 *            Initiales Spielfeld.
	 */
	@Override
	public void setStartGeneration(boolean[][] generation) {
		field = generation;

	}

	/**
	 * nextGeneration berechnet den n�chsten Spielstand.
	 * <ul>
	 * <li>Eine lebende Zelle lebt auch in der n�chsten Generation, wenn zwei
	 * oder drei ihrer acht Nachbarn in der aktuellen Generation leben.</li>
	 * <li>Eine lebende Zelle stirbt an �berbev�lkerung, wenn mehr als drei
	 * ihrer acht Nachbarin der aktuellen Generation leben.</li>
	 * <li>Eine lebende Zelle stirbt an Vereinsamung, falls weniger als zwei
	 * ihrer acht Nachbarn in der aktuellen Generation leben.</li>
	 * <li>Eine tote Zelle wird in der n�chsten Generation lebendig, wenn genau
	 * drei ihrer acht Nachbarn in der aktuellen Generation leben.</li>
	 * </ul>
	 */
	@Override
	public void nextGeneration() {
		boolean[][] fieldNew = new boolean[field.length][field[0].length];
		for (int x = 0; x < field.length; x++) {
			for (int y = 0; y < field[x].length; y++) {
				fieldNew[x][y]=isCellInNextGenerationAlive(countAliveAround(x,y),x,y);
			}
		}
		field = fieldNew;

	}
		
	/**
	 * isCellInNextGenerationAlive berechnet ob die Zelle in der n�chst Lebt.
	 * 
	 * @param aroundAlive Anzahl der benachbarten lebenden Zellen.
	 * @param x repr�sentiert die X-Koordinate des zu berechneten Felds.
	 * @param y repr�sentiert die Y-Koordinate des zu berechneten Felds.
	 * @return Ob die Zelle lebt. false=tot, true=lebt.
	 */
	@Override
	public boolean isCellInNextGenerationAlive(int aroundAlive, int x, int y){
		if(aroundAlive == 2 && field[x][y]){
			return true;
		}
		if(aroundAlive == 3){
			return true;
		}
		return false;
	}
	
	/**
	 * countAliveAround ber�chnet wie viele Nachbarn leben.
	 * 
	 * @param x repr�sentiert die X-Koordinate des zu berechneten Felds.
	 * @param y repr�sentiert die Y-Koordinate des zu berechneten Felds.
	 * @return Anzahl der benachbarten lebenden Felder.
	 */
	@Override
	public int countAliveAround(int x, int y){
		int aroundAlive = 0;
		if ((x > 0) && field[x - 1][y]) {
			aroundAlive++;
		}
		if ((y > 0) && field[x][y - 1]) {
			aroundAlive++;
		}
		if ((x < (field.length-1)) && field[x + 1][y]) {
			aroundAlive++;
		}
		if ((y < (field[x].length-1)) && field[x][y + 1]) {
			aroundAlive++;
		}
		if ((x > 0) && (y > 0) && field[x - 1][y - 1]) {
			aroundAlive++;
		}
		if ((x > 0) && (y < (field[x].length - 1)) && field[x - 1][y + 1]) {
			aroundAlive++;
		}
		if ((y > 0) && (x < (field.length - 1)) && field[x + 1][y - 1]) {
			aroundAlive++;
		}
		if ((y < (field[x].length - 1)) && (x < (field.length - 1)) && field[x + 1][y + 1]) {
			aroundAlive++;
		}
		return aroundAlive;
	}
	
	
	/**
	 * isCellAlive gibt zur�ck ob die Zelle noch lebt.
	 * 
	 * @param x repr�sentiert die X-Koordinate.
	 * @param y  repr�sentiert die Y-Koordinate.
	 * @return Zustand der Zelle. true=lebt und false=tot.
	 */
	@Override
	public boolean isCellAlive(int x, int y) {
		return field[x][y];
	}

}
