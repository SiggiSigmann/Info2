package liste;

/**
 * Value Ist ein Listebobjekt der Klasse MyList {@link MyList}.
 * 
 * @param <T> Typ des zu speicherten Wertes.
 * @author Tobias Sigmann
 *
 */
public class Value<T> {
	/**
	 * next Speichert das n�chste Element in der Liste.
	 */
	private Value<T> next = null;

	/**
	 * preview Speichert das vorherige Element in der Liste.
	 */
	private Value<T> preview = null;

	/**
	 * value Speichert den Wert des Elements.
	 */
	private T value = null;

	/**
	 * Value Initialisiert das Objekt mit dem �bergebenen Wert.
	 * 
	 * @param value
	 *            Wert des Listenobjektes.
	 */
	public Value(T value) {
		this.value = value;
	}

	/**
	 * setNextReferenz erm�glich das �ndern der Referenz auf das n�chste
	 * Element.
	 * 
	 * @param newReferenz
	 *            Element auf das als n�chstes Element gezeigt werden soll.
	 */
	public void setNextReferenz(Value<T> newReferenz) {
		next = newReferenz;
	}

	/**
	 * getNextReferenz liefert das Element an der n�chste stelle der Liste
	 * zur�ck.
	 * 
	 * @return Element an der n�chsten Stelle der Liste.
	 */
	public Value<T> getNextReferenz() {
		return next;
	}

	/**
	 * setPreviewReferenz erm�glich das �ndern der Referenz auf das
	 * vorhergehendes Element.
	 * 
	 * @param newReferenz
	 *            Element auf das als vorhriges Element gezeigt werden soll.
	 */
	public void setPreviewReferenz(Value<T> newReferenz) {
		preview = newReferenz;
	}

	/**
	 * getNextReferenz liefert das Element an der vorhergehenden stelle der
	 * Liste zur�ck.
	 * 
	 * @return Element an der vorhergehende Stelle der Liste.
	 */
	public Value<T> getPreviewReferenz() {
		return preview;
	}

	/**
	 * getValue liefert den Wert des aktuellen Elements zur�ck.
	 * 
	 * @return Wert des aktuellen Elements.
	 */
	public T getValue() {
		return value;
	}

}
