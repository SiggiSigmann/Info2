package liste;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * JListTest testet die Klasse MyList.
 * 
 * @author Tobias Sigmann
 *
 */
public class JListTest {

	/**
	 * testAddFristWennLeer tested ob auf eine leere liste ein Element an erster
	 * Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennLeerInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(1);
		assertEquals((int) 1, (int) list.getSize());
		assertEquals((int) 1, (int) list.get(0));
	}

	/**
	 * testAddFristWennNichtLeer tested ob auf eine nicht leere liste ein
	 * Element an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennNichtLeerInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(1);
		assertEquals(2, list.getSize());
		assertEquals((int) 1, (int) list.get(0));
	}

	/**
	 * testAddLastWennLeer tested ob auf eine leere liste ein Element an letzten
	 * Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennLeerInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addLast(1);
		assertEquals(1, list.getSize());
		assertEquals((int) 1, (int) list.get(0));
	}

	/**
	 * testAddLastWennNichtLeer tested ob auf eine nicht leere liste ein Element
	 * an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennNichtLeerInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addLast(0);
		list.addLast(1);
		assertEquals(2, list.getSize());
		assertEquals((int) 1, (int) list.get(1));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle an eine nicht
	 * leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddWennLeerInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.add(0, 1);
		assertEquals(1, list.getSize());
		assertEquals((int) 1, (int) list.get(0));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Anfang) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddAnfangInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(0, 1);
		assertEquals(3, list.getSize());
		assertEquals((int) 1, (int) list.get(0));

	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Ende) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddEndeInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(2, 1);
		assertEquals(3, list.getSize());
		assertEquals((int) 1, (int) list.get(2));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Mitte) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddMitteInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(1, 1);
		assertEquals(3, list.getSize());
		assertEquals((int) 1, (int) list.get(1));
	}

	/**
	 * testGetSize ob die richtige gr��e der Liste zur�ckgegeben wird.
	 */
	@Test
	public void testGetSizeInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(1, 1);
		list.addLast(2);
		assertEquals(4, list.getSize());
		list.addLast(2);
		assertEquals(5, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des letzten Elements.
	 */
	@Test
	public void testRemoveLastInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(1, 1);
		list.addLast(2);
		assertEquals(4, list.getSize());
		assertEquals((int) 2, (int) list.removeLast());
		assertEquals(3, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des ersten Elements.
	 */
	@Test
	public void testRemoveFirstInt() {
		MyList<Integer> list = new MyList<Integer>();
		list.addFirst(0);
		list.addFirst(0);
		list.add(1, 1);
		list.addLast(2);
		assertEquals(4, list.getSize());
		assertEquals((int) 0, (int) list.removeFirst());
		assertEquals(3, list.getSize());

	}
	// -------------------------------------------------------

	/**
	 * testAddFristWennLeer tested ob auf eine leere liste ein Element an erster
	 * Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennLeerString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddFristWennNichtLeer tested ob auf eine nicht leere liste ein
	 * Element an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennNichtLeerString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("1");
		assertEquals(2, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddLastWennLeer tested ob auf eine leere liste ein Element an letzten
	 * Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennLeerString() {
		MyList<String> list = new MyList<String>();
		list.addLast("1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddLastWennNichtLeer tested ob auf eine nicht leere liste ein Element
	 * an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennNichtLeerString() {
		MyList<String> list = new MyList<String>();
		list.addLast("0");
		list.addLast("1");
		assertEquals(2, list.getSize());
		assertEquals("1", list.get(1));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle an eine nicht
	 * leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddWennLeerString() {
		MyList<String> list = new MyList<String>();
		list.add(0, "1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Anfang) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddAnfangString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(0, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(0));

	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Ende) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddEndeString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(2, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(2));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Mitte) an eine
	 * nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddMitteString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(1));
	}

	/**
	 * testGetSize ob die richtige gr��e der Liste zur�ckgegeben wird.
	 */
	@Test
	public void testGetSizeString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		list.addLast("2");
		assertEquals(5, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des letzten Elements.
	 */
	@Test
	public void testRemoveLastString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		assertEquals("2", list.removeLast());
		assertEquals(3, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des ersten Elements.
	 */
	@Test
	public void testRemoveFirstString() {
		MyList<String> list = new MyList<String>();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		assertEquals("0", list.removeFirst());
		assertEquals(3, list.getSize());

	}
}
