package liste;

/**
 * Main ist die Klasse zum Testen der Implementierung der Klasse MyList.
 * 
 * @author Tobias Sigmann
 *
 */
public class Main {

	/**
	 * main Started den Ablauf des Programmes.
	 * 
	 * @param args
	 *            Startparameter (unbenutzt).
	 */
	public static void main(String[] args) {
		MyList list = new MyList();
		System.out.println(list.getSize());
		list.addFirst("2");
		list.removeFirst();
		list.addFirst("1");
		list.removeLast();
		list.addFirst("0");
		System.out.println(list.get(list.getSize() - 1));
		System.out.println(list.getSize());
		for (int i = 0; i < list.getSize(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
		list.addLast("3");
		list.addLast("4");
		System.out.println(list.getSize());
		for (int i = 0; i < list.getSize(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
		list.add(2, "--");
		System.out.println(list.getSize());
		for (int i = 0; i < list.getSize(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
		System.out.println(list.removeLast());
		for (int i = 0; i < list.getSize(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
		System.out.println(list.removeFirst());
		for (int i = 0; i < list.getSize(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
		/*while(true){
			list.addLast("e");
			System.out.println(list.getSize());
		}*/
		
	}

}
