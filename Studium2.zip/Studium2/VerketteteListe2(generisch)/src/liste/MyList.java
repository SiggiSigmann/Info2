package liste;

/**
 * MyList implement eine doppelt Verkettete Liste.
 * 
 * @param <T> Typ des zu speicherten Wertes.
 * @author Tobias Sigmann
 *
 */
public class MyList<T> {
	/**
	 * begin Speichert das erste Element in der Liste.
	 */
	private Value<T>  begin;

	/**
	 * end Speichert das Letzte Element in der Liste.
	 */
	private Value<T>  end;

	/**
	 * Standartkonstruktoir, hat keine Frunktion.
	 * 
	 */
	public MyList() {

	}

	/**
	 * getSize berechnet die Anhzahl der enthaltenen Elemente.
	 * 
	 * @return anzahl der Elemente.
	 */
	public int getSize() {
		if (begin == null) {
			return 0;
		} else {
			Value<T>  actuall = begin;
			int size = 1;
			while (actuall.getNextReferenz() != null) {
				size++;
				actuall = actuall.getNextReferenz();
			}
			return size;
		}

	}

	/**
	 * addFrist f�gt ein neues Element an die Erste(index = 0) Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addFirst(T value) {
		assert !value.equals("") : "Unlogisch, einen leeren String zu adden";
		if (begin == null) {
			begin = new Value<T>(value);
			end = begin;
		} else {
			Value<T> oldFirst = begin;
			Value<T> tooAdd = new Value<T>(value);
			tooAdd.setNextReferenz(oldFirst);
			oldFirst.setPreviewReferenz(tooAdd);
			begin = tooAdd;
		}

	}

	/**
	 * add f�gt ein Element an der gew�nschten Stelle hinzu.
	 * 
	 * @param index
	 *            Gibt die gew�nschte stelle das neuen Elements an.
	 * @param value
	 *            Wert des Elements.
	 */
	// ---------------------------
	public void add(int index, T value) {
		assert getSize() >= index : "Index zu gro�.";
		if (index == 0) {
			addFirst(value);
		} else if (index == getSize()) {
			addLast(value);
		} else {
			Value<T> toAdd = new Value<T>(value);
			Value<T> actuall = begin;
			int place = 0;
			while (index > place) {
				place++;
				actuall = actuall.getNextReferenz();
			}
			Value<T> preview = actuall.getPreviewReferenz();
			actuall.setPreviewReferenz(toAdd);
			preview.setNextReferenz(toAdd);
			toAdd.setPreviewReferenz(preview);
			toAdd.setNextReferenz(actuall);
		}
	}

	/**
	 * addFrist f�gt ein neues Element an die letzte Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addLast(T value) {
		assert !value.equals("") : "Unlogisch, einen leeren String zu adden";
		if (begin == null) {
			begin = new Value<T>(value);
			end = begin;
		} else {
			Value<T> oldLast = end;
			Value<T> toAdd = new Value<T>(value);
			oldLast.setNextReferenz(toAdd);
			toAdd.setPreviewReferenz(oldLast);
			end = toAdd;
		}
	}

	/**
	 * get liefert den Wert des Elementes an einer gew�nschten Stelle zur�ck.
	 * 
	 * @param index
	 *            Gibt die gew�nschte Element an.
	 * @return Wert des Elements an der Stelle index.
	 */
	public T get(int index) {
		assert index < getSize() : "Index zu gro�";
		Value<T> actuall = begin;
		int place = 0;
		while (index > place) {
			place++;
			actuall = actuall.getNextReferenz();
		}
		return (T) actuall.getValue();

	}

	/**
	 * removeLast l�scht das letzte Element in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public T removeLast() {
		assert 0 != getSize() : "Liste ist schon leer";
		Value<T> oldEnd = end;
		end = end.getPreviewReferenz();
		end.setNextReferenz(null);
		return (T) oldEnd.getValue();
	}

	/**
	 * removeFirst l�scht das erste Eelement in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public T removeFirst() {
		assert 0 != getSize() : "Liste ist schon leer";
		Value<T> oldBegin = begin;
		begin = begin.getNextReferenz();
		begin.setPreviewReferenz(null);
		return (T) oldBegin.getValue();
	}

}
