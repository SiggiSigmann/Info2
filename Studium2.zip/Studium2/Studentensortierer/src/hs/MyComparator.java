package hs;

/**
 * 
 * @author tobias_sigmann
 *
 * @param <T>
 */
public class MyComparator<T> implements java.util.Comparator<Student> {

	/**
	 * 
	 */
	public MyComparator() {
	}

	@Override
	public int compare(Student arg0, Student arg1) {
		if (!arg0.getLastname().equals(arg1.getLastname())) {
			return arg0.getLastname().compareTo(arg1.getLastname());
		} else if (!arg0.getFirstname().equals(arg1.getFirstname())) {
			return arg0.getFirstname().compareTo(arg1.getFirstname());
		} else if (!(arg0.getMatricualtionNumber() == arg1.getMatricualtionNumber())) {
			return arg0.getMatricualtionNumber() - arg1.getMatricualtionNumber();
		} else {
			return 0;
		}
		// return arg0.getMatricualtionNumber()*20;
	}

}
