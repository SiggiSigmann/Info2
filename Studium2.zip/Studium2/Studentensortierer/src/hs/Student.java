package hs;

/**
 * Die Klasse Student beschreibt die Eigenschaften eines Studentens.
 * 
 * @author tobias_sigmann
 */
public class Student {
	/**
	 * matricualtionNumber ist die 6-Stellige Matrikelnummer.
	 */
	private int matricualtionNumber;

	/**
	 * firstname ist der Vorname.
	 */
	private String firstname;

	/**
	 * lastname ist der Nachname.
	 */
	private String lastname;

	/**
	 * Initiales initialisieren der Egenschaften des Studentens.
	 * 
	 * @param firstname
	 *            ist der Vorname.
	 * @param lastname
	 *            ist der Nachname.
	 * @param matricualtionNumber
	 *            ist die 6-Stellige Matrikelnummer.
	 */
	public Student(String firstname, String lastname, int matricualtionNumber) {
		this.matricualtionNumber = matricualtionNumber;
		this.firstname = firstname;
		this.lastname = lastname;
	}

	/**
	 * getMatricualtionNumber liefer die Matrikelnummer zur�ck.
	 * 
	 * @return Matrikelnummer.
	 */
	public int getMatricualtionNumber() {
		return matricualtionNumber;
	}

	/**
	 * setMatricualtionNumber �ndert den Wert der Matrikelnummer.
	 * 
	 * @param matricualtionNumber neue Matrikelnummer.
	 */
	public void setMatricualtionNumber(int matricualtionNumber) {
		this.matricualtionNumber = matricualtionNumber;
	}

	/**
	 * getFirstname liefert des Vornamens zur�ck.
	 * 
	 * @return Vorname.
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * setFirstname �ndert den Wert des Vornamens.
	 * 
	 * @param firstname neuer Vorname
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * getLastname liefert des Nachnamens zur�ck.
	 * 
	 * @return Nachnamen.
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * setLastname �ndert den Wert des Nachnamens.
	 * 
	 * @param lastname neuer Namen.
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

}
