package hs;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Sotierversuch f�hrt eine sotierung aus.
 * 
 * @author tobias_sigmann
 */
public class Sotierversuch {

	/**
	 * main started den programmablauf.
	 * 
	 * @param args startparameter.
	 */
	public static void main(String[] args) {
		ArrayList<Student> st = new ArrayList<Student>();
		st.add(new Student("Tobias", "Sigmann", 1));
		st.add(new Student("Aobias", "Sigmann", 4));
		st.add(new Student("Tobias", "Sigmann", 3));
		st.add(new Student("Tobias", "Sigmann", 6));
		Collections.sort(st, new MyComparator<Student>());
		st.forEach((student) -> System.out.println("N: " + student.getFirstname() + " " + student.getLastname() + " M: "
				+ student.getMatricualtionNumber()));
	}

}
