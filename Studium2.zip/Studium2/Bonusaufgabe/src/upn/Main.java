package upn;

/**
 * Main ist die Klasse zum Testen der Implementierung der Klasse UPNRechner.
 * 
 * @author Tobias Sigmann
 *
 */
public class Main {
	
	/**
	 * main Started den Ablauf des Programmes.
	 * 
	 * @param args
	 *            Startparameter (unbenutzt).
	 */
	public static void main(String[] args) {
		UPNRechner rechner = new UPNRechner();
		System.out.println(rechner.calculate("15 42 18 + 61 24 - * 71 + *"));
	}

}
