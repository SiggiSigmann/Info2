package upn;

import java.util.ArrayList;
 /**
  * Die Klasse Stack realisiert Methoden zum arbeiten mit einen Stackspeicher.
  * 
  * @author tobias_sigmann
  * @param <T> Typ des gespeicherten Werte.
  */
public class Stack<T> {
	private ArrayList<T> stack = new ArrayList<T>();

	/**
	 * push legt ein element oben auf den Speicher drauf.
	 * 
	 * @param element ist das hinzuzuf�gende Element.
	 */
	public void push(T element) {
		stack.add(element);
	}

	/**
	 * pop nimmt das oberste Element und liefert es zur�ck.
	 * 
	 * @return oberstes Element.
	 */
	public T pop() {
		return stack.remove(stack.size() - 1);
	}

	/**
	 * size gibt die anzahl der elemente auf dem Speicher zur�ck.
	 * 
	 * @return Anzahl gespeicherte Elemente.
	 */
	public int size() {
		return stack.size();
	}
}
