package upn;

import java.util.StringTokenizer;

/**
 * UPNRechner implemetiert eine Methode um mit UPN-Ausdr�cken zu rechen.
 * 
 * @author tobias_sigmann
 */
public class UPNRechner {

	/**
	 * speicher simuliert einen Stack.
	 */
	private Stack<Integer> speicher = new Stack<Integer>();

	/**
	 * calculate das Ergebnis eines UPN-Ausdr�cks.
	 * 
	 * @param ausdruck
	 *            zu berechnender UPN-Ausdr�ck;
	 * @return ergebnis des UPN-Ausdr�cks.
	 */
	public int calculate(String ausdruck) {
		StringTokenizer zerteiler = new StringTokenizer(ausdruck);
		while (zerteiler.hasMoreTokens()) {
			String part = zerteiler.nextToken();
			if (part.equals("+")) {
				assert (speicher.size() > 1) : "Es sind nicht gebn�gend Werte vorhanden";
				speicher.push(speicher.pop() + speicher.pop());
			} else if (part.equals("-")) {
				assert (speicher.size() > 1) : "Es sind nicht gebn�gend Werte vorhanden";
				int z1 = speicher.pop();
				int z2 = speicher.pop();
				speicher.push(z2 - z1);
			} else if (part.equals("*")) {
				assert (speicher.size() > 1) : "Es sind nicht gebn�gend Werte vorhanden";
				speicher.push(speicher.pop() * speicher.pop());
			} else if (part.equals("/")) {
				assert (speicher.size() > 1) : "Es sind nicht gebn�gend Werte vorhanden";
				int z1 = speicher.pop();
				int z2 = speicher.pop();
				speicher.push(z2 / z1);
			} else {
				speicher.push(Integer.parseInt(part));
			}
		}
		return speicher.pop();
	}

}
