package bruch;

/**
 * In der Klasse Main werden Objekte von der Klasse Bruch erstellt und mit diesen gerechnet.
 * 
 * @author Tobias Sigmann
 *
 */
public class Main {

	/**
	 * main startsed den Ablauf des Programmes.
	 * 
	 * @param args Startparameter (nicht verwendet)
	 */
	public static void main(String[] args) {
		Bruch br1 = new Bruch(1, 4);
		Bruch br2 = new Bruch(-3, 4);
		br1.addieren(br2);
		System.out.println("Zaehler: " + br1.getZaehler());
		System.out.println("Nenner: " + br1.getNenner());

	}

}
