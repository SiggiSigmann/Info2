package staat;

import staat.menschen.Angestellter;
import staat.menschen.Beamter;
import staat.menschen.Hinterbliebenen;
import staat.menschen.Renter;
import staat.menschen.Selbstaendiger;
import staat.menschen.Student;

/**
 * Staat arbeited mit den Personen.
 * 
 * @author Tobias Sigmann
 *
 */
public class Staat {
	
	/**
	 * main, hier started der Ablauf des Programes.	
	 * @param args Startparameter (unbenutzt).
	 */
	public static void main(String[] args) {
		Student tobi = new Student(600);
		Student julian = new Student(7000);
		Angestellter heintje = new Angestellter(3000);
		Angestellter eddi = new Angestellter(13000);
		Beamter pape = new Beamter(13000);
		Beamter koerner = new Beamter(24000);
		Selbstaendiger wuertz = new Selbstaendiger(50000);
		Hinterbliebenen birgit = new Hinterbliebenen(60000);
		Renter opa = new Renter(755000);
		System.out.println("Tobi: EinkommenS.:" + tobi.getTax());
		System.out.println("Julian: EinkommenS.:" + julian.getTax());
		System.out.println("Heintje: EinkommenS.:" + heintje.getTax() + " SozialS.:" + heintje.getSocialTax());
		System.out.println("Eddi: EinkommenS.:" + eddi.getTax() + " SozialS.:" + eddi.getSocialTax());
		System.out.println("Pape: EinkommenS.:" + pape.getTax());
		System.out.println("K�rner: EinkommenS.:" + koerner.getTax());
		System.out.println("Wuertz: EinkommenS.:" + wuertz.getTax());
		System.out.println("Birgit: EinkommenS.:" + birgit.getTax() + " SozialS.:" + birgit.getSocialTax());
		System.out.println("Opa: EinkommenS.:" + opa.getTax());
	}
}
