package staat.steuer;

/**
 * Steuern stellt das Funktionen zum Montaseinkommen zur verf�gung.
 * 
 * @author Tobias Sigmann
 *
 */
public abstract class Steuern {
	/**
	 * montaseinkommen gibt das Monatseinkommen an.
	 */
	private int montaseinkommen;

	/**
	 * Steuern ist der Konstruktor der Klasse Steuern.
	 * 
	 * @param einkommen
	 *            Monatseinkommen der Person.
	 */
	protected Steuern(int einkommen) {
		this.montaseinkommen = einkommen;
	}

	/**
	 * getEinkommen liefert das monatliche einkommen zur�ck.
	 * 
	 * @return Monatseinkommen.
	 */
	protected int getEinkommen() {
		return montaseinkommen;
	}

	/**
	 * setEinkommen setzt das Manatseinkommen.
	 * 
	 * @param einkommen
	 *            zu setzende Manatseinkommen.
	 */
	protected void setEinkommen(int einkommen) {
		montaseinkommen = einkommen;
	}
}
