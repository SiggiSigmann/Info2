package staat.steuer;

/**
 * Einkommenssteuer stellt Methoden zur Einkommenssteuerberechnung zur
 * verf�gung.
 * 
 * @author Tobias Sigmann
 *
 */
public abstract class Einkommenssteuer extends Steuern {
	/**
	 * In STEUERS�TZE k�nnen die verscheidenen Steuerst�ze in verh�ltniss zu dem
	 * einkommen abgelesen werden.
	 */
	public static final int[][] STEUERSAETZE = new int[][] {{0, 12000, 10},
															{12001, 24000, 25},
															{24001, 50000, 30},
															{50001, 75000, 40},
															{75001, Integer.MAX_VALUE, 50}};

	/**
	 * mussEinkommensstuerenZahle gibt an ob Einkommenssteuer gezahlt werden
	 * muss.
	 */
	private boolean mussEinkommensstuerenZahle;

	/**
	 * Einkommenssteuer ist der Konstruktor der klasse Einkommenssteuer.
	 * 
	 * @param einkommen	pro Monat.
	 * @param einkommensstueren gibt an ob Einkommenssteuer gezahlt werden muss.
	 */
	protected Einkommenssteuer(int einkommen, boolean einkommensstueren) {
		super(einkommen);
		mussEinkommensstuerenZahle = einkommensstueren;
	}

	/**
	 * getTax berechnet die h�he der zu zahlenden Steuern.
	 * 
	 * @return zu zahlenden Steuern.
	 */
	public int getTax() {
		if (mussEinkommensstuerenZahle) {
			return (getEinkommen() * getSteuersatz()) / 100;
		} else {
			return 0;
		}
	}

	/**
	 * getSteuersatz gibt den prozentsatz der zu zahlenden Steuern an.
	 * 
	 * @return prozentsatz in Prozent.
	 */
	private int getSteuersatz() {
		for (int i = 0; i < STEUERSAETZE.length; i++) {
			if ((STEUERSAETZE[i][0] <= getEinkommen()) && (getEinkommen() <= STEUERSAETZE[i][1])) {
				return STEUERSAETZE[i][2];
			}
		}
		return 0;
	}
}
