package staat.steuer;

/**
 * Sozialsteuer implementier die Berechnung.
 * 
 * @author Tobias Sigmann
 */
public abstract class Sozialsteuer extends Einkommenssteuer {

	/**
	 * Sozialsteuer ist der Konstruktor der klasse Sozialsteuer.
	 * 
	 * @param einkommen pro Montag.
	 * @param einkommensstueren gibt an ob Einkommenssteuer gezahlt werden muss. 
	 */
	protected Sozialsteuer(int einkommen, boolean einkommensstueren) {
		super(einkommen, einkommensstueren);
	}

	/**
	 * getSocialTax berechnet die zu zahlenden Sozialsteuern.
	 * 
	 * @return Die zu zahlenden Sozialsteuern.
	 */
	public int getSocialTax() {
		return (getEinkommen() * 28) / 100;
	}

}
