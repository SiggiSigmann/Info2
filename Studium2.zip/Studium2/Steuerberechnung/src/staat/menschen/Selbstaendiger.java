package staat.menschen;

import staat.steuer.Einkommenssteuer;

/**
 * Selbstaendiger stellt Metoden zu Steuerberechnung f�r einen Selbstaendiger
 * zur verf�gung.
 * 
 * @author Tobias Sigmann
 *
 */
public class Selbstaendiger extends Einkommenssteuer {

	/**
	 * Selbstaendiger ist der Konstruktor von Selbstaendiger.
	 * 
	 * @param einkommen
	 *            Monatseinkommen.
	 */
	public Selbstaendiger(int einkommen) {
		super(einkommen, true);
	}

}
