package staat.menschen;

import staat.steuer.Sozialsteuer;

/**
 * Hinterbliebenen stellt Metoden zu Steuerberechnung f�r einen Hinterbliebenen
 * zur verf�gung.
 * 
 * @author Tobias Sigmann
 *
 */
public class Hinterbliebenen extends Sozialsteuer {

	/**
	 * Hinterbliebenen ist der Konstruktor von Hinterbliebenen.
	 * 
	 * @param einkommen
	 *            Monatseinkommen.
	 */
	public Hinterbliebenen(int einkommen) {
		super(einkommen, false);
	}

}
