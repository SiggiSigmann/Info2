package staat.menschen;

import staat.steuer.Einkommenssteuer;

/**
 * Student stellt Metoden zu Steuerberechnung f�r einen Student zur verf�gung.
 * 
 * @author Tobias Sigmann
 *
 */
public class Student extends Einkommenssteuer {
	/**
	 * Student ist der Konstruktor von Student.
	 * 
	 * @param einkommen Monatseinkommen.
	 */
	public Student(int einkommen) {
		super(einkommen, true);
	}

	/**
	 * getTax berechnet die zu Zahlenden Steuern.
	 * 
	 * @return zu Zahlende Steuern.
	 */
	@Override
	public int getTax() {
		if (getEinkommen() > 6000) {
			return super.getTax();
		} else {
			return 0;
		}
	}

}
