package staat.menschen;

import staat.steuer.Sozialsteuer;

/**
 * Angestellter stellt Methoden zur berechnung der
 * Steuern eines Angestellten zur verf�gung.
 * 
 * @author tobias_sigmann
 */
public class Angestellter extends Sozialsteuer {
	
	/**
	 * Angestellter ist der Konstruktor.
	 * 
	 * @param einkommen Monatseinkommen des Angestellten.
	 */
	public Angestellter(int einkommen) {
		super(einkommen, true);
	}

	/**
	 * getTax berechnet die zu Zahlenden Steuern.
	 * 
	 * @return zu Zahlende Steuern.
	 */
	@Override
	public int getTax() {
		if (getEinkommen() < 6000) {
			return super.getTax();
		} else {
			return 0;
		}
	}

}
