package staat.menschen;

import staat.steuer.Einkommenssteuer;

/**
 * Renter repr�sentiert einen Rentner.
 * 
 * @author Tobias Sigmann
 */
public class Renter extends Einkommenssteuer {

	/**
	 * Renter initialisiert das Einkommen.
	 * 
	 * @param einkommen
	 *            pro Monat.
	 */
	public Renter(int einkommen) {
		super(einkommen, false);
	}

}
