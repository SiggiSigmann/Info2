package staat.menschen;

import staat.steuer.Einkommenssteuer;

/**
 * Beamter stelt Methoden zur Berechnung seiner Steuern zu ferf�gung.
 * 
 * @author tobias_sigmann
 *
 */
public class Beamter extends Einkommenssteuer {
 
	/**
	 * Beamter initialisiert Beamter.
	 * 
	 * @param einkommen
	 *            Monatseinkommen.
	 */
	public Beamter(int einkommen) {
		super(einkommen, true);
	}

}
