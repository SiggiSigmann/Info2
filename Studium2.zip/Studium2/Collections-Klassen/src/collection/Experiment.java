package collection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.Vector;

public class Experiment {

	public static void main(String[] args) {

		for (int i = 0; i < 10; i++) {
			// Test1
			ArrayList<Integer> al = new ArrayList<>();
			Vector<Integer> vi = new Vector<>();
			LinkedList<Integer> ll = new LinkedList<>();
			HashSet<Integer> hs = new HashSet<>();
			TreeSet<Integer> ts = new TreeSet<>();

			System.out.println("Test 1");
			System.out.println(TimePicker.measureAdd(al) + " ns");
			System.out.println(TimePicker.measureAdd(vi) + " ns");
			System.out.println(TimePicker.measureAdd(ll) + " ns");
			System.out.println(TimePicker.measureAdd(hs) + " ns");
			System.out.println(TimePicker.measureAdd(ts) + " ns");
			System.out.println("--------------------------------");

			// Test2
			System.out.println("Test 2");
			ArrayList<Integer> al2 = new ArrayList<>(100000);
			Vector<Integer> vi2 = new Vector<>(100000);
			LinkedList<Integer> ll2 = new LinkedList<>();
			System.out.println(TimePicker.measureAddFirst(al2) + " ns");
			System.out.println(TimePicker.measureAddFirst(vi2) + " ns");
			System.out.println(TimePicker.measureAddFirst(ll2) + " ns");
			System.out.println("--------------------------------");

			// Teil3
			System.out.println("Test 3");
			System.out.println(TimePicker.searchLastAdd(al) + " ns");
			System.out.println(TimePicker.searchLastAdd(vi) + " ns");
			System.out.println(TimePicker.searchLastAdd(ll) + " ns");
			System.out.println(TimePicker.searchLastAdd(hs) + " ns");
			System.out.println(TimePicker.searchLastAdd(ts) + " ns");
			System.out.println("--------------------------------");

			// Teil4
			System.out.println("Test 4");
			System.out.println(TimePicker.searchLastAddBin(al) + " ns");
			System.out.println(TimePicker.searchLastAddBin(vi) + " ns");
			System.out.println("--------------------------------");

			// Teil5
			System.out.println("Test 5");
			System.out.println(TimePicker.searchLastElement(al) + " ns");
			System.out.println(TimePicker.searchLastElement(vi) + " ns");
			System.out.println(TimePicker.searchLastElement(ll) + " ns");
			System.out.println(TimePicker.searchLastElement(hs) + " ns");
			System.out.println(TimePicker.searchLastElement(ts) + " ns");
			System.out.println("--------------------------------");

			// Teil6
			System.out.println("Test 6");
			ArrayList<Integer> alIterator = new ArrayList<>();
			ArrayList<Integer> alStream = new ArrayList<>();
			System.out.println(TimePicker.fillWithIterator(alIterator) + " ns");
			System.out.println(TimePicker.fillWithStream(alStream) + " ns");
			System.out.println("--------------------------------");

			// Teil7
			System.out.println("Test 7");
			System.out.println(TimePicker.addAllJustPayNumbersIterator(alIterator) + " ns");
			System.out.println(TimePicker.addAllJustPayNumbersStream(alStream) + " ns");
			System.out.println("-----------------------------------------------------------");
			System.out.println("-----------------------------------------------------------");
		}
	}

}
