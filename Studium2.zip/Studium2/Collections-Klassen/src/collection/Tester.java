package collection;

import java.util.ArrayList;
import java.util.Vector;

public class Tester {
	public static void main(String[] args) {
		anh�ngen();
	}
	
	
	public static void anh�ngen(){
		ArrayList<Integer> alist = new ArrayList<>(100000);
		Vector<Integer> vec = new Vector<Integer>(100000);
		long start = System.nanoTime();
		for(int i=0;i>99999;i++){
			alist.add(i);
		}
		long end = System.nanoTime();
		long arrayTime=  (end - start);
		start = System.nanoTime();
		for(int i=0;i>99999;i++){
			vec.add(i);
		}
		end = System.nanoTime();
		long vectorTime=  (end - start);
		System.out.println(vectorTime + " "+ arrayTime);
		if(vectorTime<arrayTime){
			System.out.println("Vector war schneller: " + vectorTime);
		}
		if(arrayTime<vectorTime){
			System.out.println("ArrayList war schneller: " + arrayTime);
		}
		if(arrayTime==vectorTime){
			System.out.println("gleich");
		}
	}
}
