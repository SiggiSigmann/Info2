package collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.omg.Messaging.SyncScopeHelper;



public class TimePicker {

	public static long measureAdd(Collection<Integer> c) {
		long start, ende;
		start = System.nanoTime();
		for (int i = 0; i < 99999; i++) {
			c.add(i);
		}
		ende = System.nanoTime();
		return ende - start;
	}

	public static long measureAddFirst(List<Integer> c) {
		long start, ende;
		start = System.nanoTime();
		for (int i = 0; i < 99999; i++) {
			c.add(0, i);
		}
		ende = System.nanoTime();
		return ende - start;
	}

	public static long searchLastAdd(Collection<Integer> c) {
		long start, ende;
		Iterator<Integer> i = c.iterator();
		start = System.nanoTime();
		while(i.hasNext()){
			i.next();
		}
		ende = System.nanoTime();
		return ende - start;
	}
	
	public static long searchLastAddBin(List<Integer> c) {
		long start, ende;
		start = System.nanoTime();
		Collections.binarySearch(c, c.size());
		ende = System.nanoTime();
		return ende - start;
	}
	
	public static long searchLastElement(Collection<Integer> c){
		long start, ende;
		
		start = System.nanoTime();
		c.contains(99999);
		ende = System.nanoTime();
		return ende - start;
	}
	
	public static long fillWithIterator(ArrayList<Integer> l){
		long start, ende;
		Random r = new Random();
		start = System.nanoTime();
		for (int i = 0; i < 10000; i++) {
			l.add(r.nextInt());
		}
		ende = System.nanoTime();
		return ende - start;
	}
	
	public static long fillWithStream(ArrayList<Integer> l){
		long start, ende;
		start = System.nanoTime();
		Stream.generate(new Random()::nextInt).limit(10000).forEach(l::add);
		ende = System.nanoTime();
		return ende - start;
	}
	
	public static long addAllJustPayNumbersIterator(ArrayList<Integer> l){
		long start, ende;
		int ergebnis=0;
		Iterator<Integer> i = l.iterator();
		start = System.nanoTime();
		while(i.hasNext()){
			int n = i.next();
			if(n%2==0){
				ergebnis+=n;
			}
		}
		ende = System.nanoTime();
		System.out.println("Ergebnis: " + ergebnis);
		return ende - start;
	}
	
	public static long addAllJustPayNumbersStream(ArrayList<Integer> l){
		long start, ende;
		int ergebnis=0;
		start = System.nanoTime();
		ergebnis = l.stream().limit(l.size()).filter((x) -> x%2==0).mapToInt(Integer::valueOf).sum();
		ende = System.nanoTime();
		System.out.println("Ergebnis: " + ergebnis);
		return ende - start;
	}
}
