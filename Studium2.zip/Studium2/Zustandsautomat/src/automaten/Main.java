package automaten;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		int[][] tabelle = new int[][] { { 1, 1 }, { 2, 3 }, { 2, 4 }, { 2, 3 }, { 2, 3 } };
		Scanner s = new Scanner(System.in);
		ZustandsautomatList za1 = new ZustandsautomatList(tabelle);
		ZustandsautomatSwitch za2 = new ZustandsautomatSwitch();
		System.out.print(za1.trigger("100010011101001") + " ");
		System.out.println(za2.trigger("100010011101001"));
		System.out.print(za1.trigger("")+" ");
		System.out.println(za2.trigger(""));
		System.out.print(za1.trigger("000000000000000000000000000000000000000")+" ");
		System.out.println(za2.trigger("000000000000000000000000000000000000000"));
		System.out.print(za1.trigger("11111111111111111111111111")+" ");
		System.out.println(za2.trigger("11111111111111111111111111"));
		System.out.print(za1.trigger("01011011011011011011011011011011011011011011011011011011011")+" ");
		System.out.println(za2.trigger("01011011011011011011011011011011011011011011011011011011011"));
		System.out.print(za1.trigger("0")+" ");
		System.out.println(za2.trigger("0"));
		System.out.print(za1.trigger("1")+" ");
		System.out.println(za2.trigger("1"));
		System.out.println("--------------------------------------------------------------");
		while(true){
			String test = s.nextLine();
			System.out.println("Mit " + test + " :");
			System.out.print(za1.trigger(test) + " ");
			System.out.println(za2.trigger(test));
		}
	}
}
