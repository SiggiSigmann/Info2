package automaten;
/**
 * ZustandsautomatList realisiert die implementierung eines Zustandautomates mithilfer einer �bergangstabelle.
 * 
 * @author tobias_sigmann
 */
public class ZustandsautomatList {
	/**
	 * tabelle repr�sentiert die zustands�bergangstabelle eines DEA. Die
	 * Zust�nde entsprechen der Platzierung im array. Der �bergang bei 0
	 * enstprichht der ersten stelle im inneren Array. Bei 1 etspr�chend die
	 * zweite.
	 */
	private int[][] tabelle;
	private int zustand = 0;

	/**
	 * ZustandsautomatList konstrucktor des Automantens, setzt die �bergangsbedingungen.
	 * 
	 * @param tabelle Zustands�bergangstabelle. Index repr�sentiert den Zustand, bzw die Eingabe.
	 */
	public ZustandsautomatList(int[][] tabelle) {
		this.tabelle = tabelle;
	}

	/**
	 * trigger f�hrt die bearbeitung des Wortes aus.
	 * 
	 * @param eingabe Eingabewort.
	 * @return Endzustand nach Bearbeitung.
	 */
	public int trigger(String eingabe) {
		zustand = 0;
		while (!eingabe.equals("")) {
			switch (eingabe.charAt(0)) {
			case '0':
				zustand = tabelle[zustand][0];
				break;
			case '1':
				zustand = tabelle[zustand][1];
				break;
			}
			eingabe = eingabe.substring(1);
		}
		return zustand;
	}

}
