package automaten;

/**
 * ZustandsautomatSwitch realisiert die implementierung eines Zustandautomates.
 * 
 * @author tobias_sigmann
 */
public class ZustandsautomatSwitch {
	/**
	 * Zustand speichert die m�glichen Zust�nde.
	 * 
	 * @author tobias_sigmann
	 */
	private enum Zustand {
		Z0, Z1, Z2, Z3, Z4;
		
	}

	/**
	 * state speichert den aktuellen zustand des Automats;
	 */
	private Zustand state;
	
	/**
	 * speichert das aktuell zu bearbeitende Wort.
	 */
	private String word;
	
	/**
	 * trigger bearbeitet das Wort und gibt den letzten zustand zur�ck.
	 * 
	 * @param s Zu bearbeitende Wort.
	 * @return Letzter Zustand.
	 */
	public int trigger(String s) {
		
		state = Zustand.Z0;
		word = s;
		
		while (word.length() != 0) {
			switch (state) {
			case Z0:
				if (word.charAt(0) == '0') {
					state = Zustand.Z1;
				} else {
					state = Zustand.Z1;
				}
				break;
			case Z1:
				if (word.charAt(0) == '0') {
					state = Zustand.Z2;
				} else {
					state = Zustand.Z3;
				}
				break;
			case Z2:
				if (word.charAt(0) == '0') {
					state = Zustand.Z2;
				} else {
					state = Zustand.Z4;
				}
				break;
			case Z3:
				if (word.charAt(0) == '0') {
					state = Zustand.Z2;
				} else {
					state = Zustand.Z3;
				}
				break;
			case Z4:
				if (word.charAt(0) == '0') {
					state = Zustand.Z2;
				} else {
					state = Zustand.Z3;
				}
				break;
			default:
				break;
			}
			word = word.substring(1, word.length());
		}
		return state.ordinal();
	}

}
