package liste;

/**
 * MyList implement eine doppelt Verkettete Liste.
 * 
 * @author Tobias Sigmann
 *
 */
public class MyList {
	/**
	 * begin Speichert das erste Element in der Liste.
	 */
	private Value begin;

	/**
	 * end Speichert das Letzte Element in der Liste.
	 */
	private Value end;

	/**
	 * Standartkonstruktoir, hat keine Frunktion.
	 * 
	 */
	public MyList() {

	}

	/**
	 * getSize berechnet die Anhzahl der enthaltenen Elemente.
	 * 
	 * @return anzahl der Elemente.
	 */
	public int getSize() {
		if (begin == null) {
			return 0;
		} else {
			Value actuall = begin;
			int size = 1;
			while (actuall.getNextReferenz() != null) {
				size++;
				actuall = actuall.getNextReferenz();
			}
			return size;
		}

	}

	/**
	 * addFrist f�gt ein neues Element an die Erste(index = 0) Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addFirst(String value) {
		assert !value.equals("") : "Unlogisch, einen leeren String zu adden";
		if (begin == null) {
			begin = new Value(value);
			end = begin;
		} else {
			Value oldFirst = begin;
			Value tooAdd = new Value(value);
			tooAdd.setNextReferenz(oldFirst);
			oldFirst.setPreviewReferenz(tooAdd);
			begin = tooAdd;
		}

	}

	/**
	 * add f�gt ein Element an der gew�nschten Stelle hinzu.
	 * 
	 * @param index
	 *            Gibt die gew�nschte stelle das neuen Elements an.
	 * @param value
	 *            Wert des Elements.
	 */
	// ---------------------------
	public void add(int index, String value) {
		assert getSize() >= index : "Index zu gro�.";
		if (index == 0) {
			addFirst(value);
		} else if (index == getSize()) {
			addLast(value);
		} else {
			Value toAdd = new Value(value);
			Value actuall = begin;
			int place = 0;
			while (index > place) {
				place++;
				actuall = actuall.getNextReferenz();
			}
			Value preview = actuall.getPreviewReferenz();
			actuall.setPreviewReferenz(toAdd);
			preview.setNextReferenz(toAdd);
			toAdd.setPreviewReferenz(preview);
			toAdd.setNextReferenz(actuall);
		}
	}

	/**
	 * addFrist f�gt ein neues Element an die letzte Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addLast(String value) {
		assert !value.equals("") : "Unlogisch, einen leeren String zu adden";
		if (begin == null) {
			begin = new Value(value);
			end = begin;
		} else {
			Value oldLast = end;
			Value toAdd = new Value(value);
			oldLast.setNextReferenz(toAdd);
			toAdd.setPreviewReferenz(oldLast);
			end = toAdd;
		}
	}

	/**
	 * get liefert den Wert des Elementes an einer gew�nschten Stelle zur�ck.
	 * 
	 * @param index
	 *            Gibt die gew�nschte Element an.
	 * @return Wert des Elements an der Stelle index.
	 */
	public String get(int index) {
		assert index < getSize() : "Index zu gro�";
		Value actuall = begin;
		int place = 0;
		while (index > place) {
			place++;
			actuall = actuall.getNextReferenz();
		}
		return actuall.getValue();

	}

	/**
	 * removeLast l�scht das letzte Eelement in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public String removeLast() {
		assert 0 != getSize() : "Liste ist schon leer";
		Value oldEnd = end;
		end = end.getPreviewReferenz();
		end.setNextReferenz(null);
		return oldEnd.getValue();
	}

	/**
	 * removeFirst l�scht das erste Eelement in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public String removeFirst() {
		assert 0 != getSize() : "Liste ist schon leer";
		Value oldBegin = begin;
		begin = begin.getNextReferenz();
		begin.setPreviewReferenz(null);
		return oldBegin.getValue();
	}

}
