package liste;

/**
 * Value Ist ein Listebobjekt der Klasse MyList {@link MyList}.
 * 
 * @author Tobias Sigmann
 *
 */
public class Value {
	/**
	 * next Speichert das n�chste Element in der Liste.
	 */
	private Value next = null;

	/**
	 * preview Speichert das vorherige Element in der Liste.
	 */
	private Value preview = null;

	/**
	 * value Speichert den Wert des Elements.
	 */
	private String value = null;

	/**
	 * Value Initialisiert das Objekt mit dem �bergebenen Wert.
	 * 
	 * @param value
	 *            Wert des Listenobjektes.
	 */
	public Value(String value) {
		this.value = value;
	}

	/**
	 * calsSize berechnet die gr��e der Liste.
	 * 
	 * @return gr��e der Liste.
	 */
	public int calcSize() {
		if (next == null) {
			return 1;
		} else {
			return next.calcSize() + 1;
		}
	}

	/**
	 * setNextReferenz erm�glich das �ndern der Referenz auf das n�chste
	 * Element.
	 * 
	 * @param newReferenz
	 *            Element auf das als n�chstes Element gezeigt werden soll.
	 */
	public void setNextReferenz(Value newReferenz) {
		next = newReferenz;
	}

	/**
	 * getNextReferenz liefert das Element an der n�chste stelle der Liste
	 * zur�ck.
	 * 
	 * @return Element an der n�chsten Stelle der Liste.
	 */
	public Value getNextReferenz() {
		return next;
	}

	/**
	 * setPreviewReferenz erm�glich das �ndern der Referenz auf das
	 * vorhergehendes Element.
	 * 
	 * @param newReferenz
	 *            Element auf das als vorhriges Element gezeigt werden soll.
	 */
	public void setPreviewReferenz(Value newReferenz) {
		preview = newReferenz;
	}

	/**
	 * getNextReferenz liefert das Element an der vorhergehenden stelle der
	 * Liste zur�ck.
	 * 
	 * @return Element an der vorhergehende Stelle der Liste.
	 */
	public Value getPreviewReferenz() {
		return preview;
	}

	/**
	 * getReferenz liefert die Referenz auf sich selbst zur�ck.
	 * 
	 * @return Referenz auf sich Selbst.
	 */
	public Value getReferenz() {
		return this;
	}

	/**
	 * getReferenz liefert das Objekt an der gew�nschten Stelle zur�ck.
	 * 
	 * @param index
	 *            gibt den Index des momentanen Elements an.
	 * @param indexOfElement
	 *            gibt den Index des gew�nschten Elementes an.
	 * @return Referenz auf sich Selbst.
	 */
	public Value getReferenz(int index, int indexOfElement) {
		if (index == indexOfElement) {
			return this;
		} else {
			return next.getReferenz(++index, indexOfElement);
		}
	}

	/**
	 * get liefert den Wert an einer gew�nschten Stelle zur�ck.
	 * 
	 * @param index
	 *            gibt den Index des momentanen Elements an.
	 * @param indexOfElement
	 *            gibt den Index des gew�nschten Elementes an.
	 * @return Wert des Objektes an der Stelle indexOfElement.
	 */
	public String get(int index, int indexOfElement) {
		if (index == indexOfElement) {
			return value;
		} else {
			return next.get(++index, indexOfElement);
		}
	}

	/**
	 * addLast erm�glicht das Hinzuf�gen eines Elements an der letzten Stelle
	 * der Liste.
	 * 
	 * @param newElement
	 *            ist das Element das an der Letzten Stelle hinzugef�gt werden
	 *            soll.
	 */
	public void addLast(Value newElement) {
		if (preview == null) {
			preview = newElement;
			// p�bergebe diese ding weil next ist das hier
		} else {
			next.addLast(newElement);
		}
	}

	/**
	 * getValue liefert den Wert des aktuellen Elements zur�ck.
	 * 
	 * @return Wert des aktuellen Elements.
	 */
	public String getValue() {
		return value;
	}

}
