package liste;

/**
 * MyList implement eine doppelt Verkettete Liste.
 * 
 * @author Tobias Sigmann
 *
 */
public class MyList {
	/**
	 * begin Speichert das erste Element in der Liste.
	 */
	private Value begin;

	/**
	 * end Speichert das Letzte Element in der Liste.
	 */
	private Value end;

	/**
	 * Standartkonstruktoir, hat keine Frunktion.
	 * 
	 */
	public MyList() {

	}

	/**
	 * getSize berechnet die Anhzahl der enthaltenen Elemente.
	 * 
	 * @return anzahl der Elemente.
	 */
	public int getSize() {
		if (begin == null) {
			return 0;
		} else {
			return begin.calcSize();
		}

	}

	/**
	 * addFrist f�gt ein neues Element an die Erste(index = 0) Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addFirst(String value) {
		if (begin == null) {
			begin = new Value(value);
			end = begin;
		} else {
			Value oldFirst = begin.getReferenz();
			Value tooAdd = new Value(value);
			tooAdd.setNextReferenz(oldFirst);
			oldFirst.setPreviewReferenz(tooAdd);
			begin = tooAdd;
		}

	}

	/**
	 * add f�gt ein Element an der gew�nschten Stelle hinzu.
	 * 
	 * @param index
	 *            Gibt die gew�nschte stelle das neuen Elements an.
	 * @param value
	 *            Wert des Elements.
	 */
	public void add(int index, String value) {
		if (begin == null) {
			begin = new Value(value);
			end = begin;
		} else {
			if (index == 0) {
				addFirst(value);
			} else if (index == getSize()) {
				addLast(value);
			} else {
				Value oldPreview = begin.getReferenz(0, index - 1);
				Value oldNext = begin.getReferenz(0, index);
				Value toAdd = new Value(value);
				oldPreview.setNextReferenz(toAdd);
				oldNext.setPreviewReferenz(toAdd);
				toAdd.setNextReferenz(oldNext);
				toAdd.setPreviewReferenz(oldPreview);
			}
		}
	}

	/**
	 * addFrist f�gt ein neues Element an die letzte Stelle hinzu.
	 * 
	 * @param value
	 *            Wert des Elements.
	 */
	public void addLast(String value) {
		if (begin == null) {
			begin = new Value(value);
			end = begin;
		} else {
			Value oldLast = end.getReferenz();
			Value toAdd = new Value(value);
			oldLast.setNextReferenz(toAdd);
			toAdd.setPreviewReferenz(oldLast);
			end = toAdd;
		}
	}

	/**
	 * get liefert den Wert des Elementes an einer gew�nschten Stelle zur�ck.
	 * 
	 * @param index
	 *            Gibt die gew�nschte Element an.
	 * @return Wert des Elements an der Stelle index.
	 */
	public String get(int index) {
		return begin.get(0, index);
	}

	/**
	 * removeLast l�scht das letzte Eelement in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public String removeLast() {
		Value oldEnd = end;
		if (getSize() == 1) {
			end = null;
			begin = null;
		} else {
			end = oldEnd.getPreviewReferenz();
			end.setNextReferenz(null);
		}
		return oldEnd.getValue();
	}

	/**
	 * removeFirst l�scht das erste Eelement in der Liste.
	 * 
	 * @return Wert des gel�schten Elements.
	 */
	public String removeFirst() {
		Value oldBegin = begin;
		if (getSize() == 1) {
			begin = null;
			end = null;
		} else {
			begin = oldBegin.getNextReferenz();
			begin.setPreviewReferenz(null);
		}
		return oldBegin.getValue();
	}

}
