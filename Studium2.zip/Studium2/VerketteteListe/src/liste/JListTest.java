package liste;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * JListTest testet die Klasse MyList.
 * 
 * @author Tobias Sigmann
 *
 */
public class JListTest {

	/**
	 * testAddFristWennLeer tested ob auf eine leere liste ein Element an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennLeer() {
		MyList list = new MyList();
		list.addFirst("1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddFristWennNichtLeer tested ob auf eine nicht leere liste ein Element an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddFristWennNichtLeer() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("1");
		assertEquals(2, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 *  testAddLastWennLeer tested ob auf eine leere liste ein Element an letzten Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennLeer() {
		MyList list = new MyList();
		list.addLast("1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddLastWennNichtLeer tested ob auf eine nicht leere liste ein Element an erster Stelle hinzugef�gt werden kann.
	 */
	@Test
	public void testAddLastWennNichtLeer() {
		MyList list = new MyList();
		list.addLast("0");
		list.addLast("1");
		assertEquals(2, list.getSize());
		assertEquals("1", list.get(1));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle an eine nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddWennLeer() {
		MyList list = new MyList();
		list.add(0, "1");
		assertEquals(1, list.getSize());
		assertEquals("1", list.get(0));
	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Anfang) an eine nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddAnfang() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(0, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(0));

	}

	/**
	 * testAddWennLeer ob ein Element an einer bestimmten Stelle(Ende) an eine nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddEnde() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(2, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(2));
	}

	/**
	 *  testAddWennLeer ob ein Element an einer bestimmten Stelle(Mitte) an eine nicht leere Liste hinzugef�ht werden kann.
	 */
	@Test
	public void testAddMitte() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		assertEquals(3, list.getSize());
		assertEquals("1", list.get(1));
	}

	/**
	 * testGetSize ob die richtige gr��e der Liste zur�ckgegeben wird.
	 */
	@Test
	public void testGetSize() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		list.addLast("2");
		assertEquals(5, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des letzten Elements.
	 */
	@Test
	public void testRemoveLast() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		assertEquals("2", list.removeLast());
		assertEquals(3, list.getSize());
	}

	/**
	 * testRemoveLast testet das entfernen des ersten Elements.
	 */
	@Test
	public void testRemoveFirst() {
		MyList list = new MyList();
		list.addFirst("0");
		list.addFirst("0");
		list.add(1, "1");
		list.addLast("2");
		assertEquals(4, list.getSize());
		assertEquals("0", list.removeFirst());
		assertEquals(3, list.getSize());

	}

}
