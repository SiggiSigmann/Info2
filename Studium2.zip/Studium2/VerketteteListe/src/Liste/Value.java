package Liste;

public class Value {
	private Value next=null, preview=null;
	//private int index;//?
	private String value=null;
	
	public Value(){
		this.preview=null;
	}
	
	public Value(String value){
		this.value=value;
	}
	
	public Value(Value preview){
		this.preview=preview;
	}
	
	public void addFirst(Value newElement){
		
	}
	
	public void addLast(Value newElement){
		if(preview==null){
			preview= newElement;
			//p�bergebe diese ding weil next ist das hier
		}else{
			next.addLast(newElement);
		}
	}
	
	public void add(int index, Value newElement){
		
	}
	
	public String get(int index){
		return null;
	}
	
	public String removeFirst(){
		return null;
	}
	
	public String removeLast(){
		return null;
	}
	public int getSize(){
		return 0;
	}
	
}
