package Liste;

public class MyList {
	Value begin, end;
	int length=0;
	
	public MyList(){
		
	}
	
	public void addFirst(String value){
		
	}
	
	public void addLast(String value){
		Value last = new Value(value);
		end=last;
		begin.addFirst(last);
	}
	
	public void add(int index, String value){
		if(length==0){
			begin=new Value();
			end=begin;
		}
	}
	
	public String get(int index){
		return null;
	}
	
	public String removeFirst(){
		return null;
	}
	
	public String removeLast(){
		return null;
	}
	public int getSize(){
		return length;
	}
}
